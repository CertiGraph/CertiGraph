(* obj/x86_LINUX/cilversion.ml.  Generated from cilversion.ml.in by configure. *)

let cilVersionMajor = 1
let cilVersionMinor = 5
let cilVersionRev   = 1
let cilVersion      = "1.5.1"
