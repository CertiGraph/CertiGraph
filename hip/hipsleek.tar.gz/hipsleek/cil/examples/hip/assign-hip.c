int foo()
{
  return 1;
}

int main() {
  int zzzzzz;
  int yyy = foo();
  zzzzzz = zzzzzz + 1;
  return 0;
}
