
int k;
int n;

void increase()
{
	k = k+n;
}
