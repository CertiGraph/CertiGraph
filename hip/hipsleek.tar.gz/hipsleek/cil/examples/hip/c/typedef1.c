typedef int number;

number foo()
{
  return 0;
}

void main()
{
}
