int foo(int *zzzz)
{
  *zzzz = 1;
}

void main()
{
}
