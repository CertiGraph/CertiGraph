typedef int number;

typedef number nat;

number foo(nat x)
{
  return 0;
}

nat main()
{
  return 2;
}
