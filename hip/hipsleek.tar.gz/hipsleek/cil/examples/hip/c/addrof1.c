int foo ()
{
  int *p;
  int z;
  z = 1;
  p = &z;
  return *p;
}

void main ()
{
  return;
}
