int foo()
{
  int a[10][10];
  a[0][1] = 1;
  return a[0][1];
}

void main()
{
  return;
}
