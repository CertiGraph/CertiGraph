
int k;
int n;

void increase()
{
	k = k+1;
	n = n+1;
}

void increase_n(int k)
{
	n = n+k;
}
