/*
  Copyright (c) Microsoft Corporation.  All rights reserved.
*/
void main() {
  int x;
  int *y = 0;
  //x = *y;
  //@ assert y' = null;
}
