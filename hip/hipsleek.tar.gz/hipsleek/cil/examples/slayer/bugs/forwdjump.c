/*  Copyright (c) Microsoft Corporation.  All rights reserved. */
void main() {
  int x, y;
  x = 0;
  goto L;
  x = 4;
 L: y = x;
  return;
}
