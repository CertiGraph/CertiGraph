/*  Copyright (c) Microsoft Corporation.  All rights reserved. */
#include "slayer.h"

int main() {
  int x;
  free(&x);
}
