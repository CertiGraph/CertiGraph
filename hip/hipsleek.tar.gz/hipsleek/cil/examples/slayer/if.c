/*  Copyright (c) Microsoft Corporation.  All rights reserved.  */

void main() {
  int x, y;
  y = 0;
  if(x==y) { x = 0; } else { x = 1; }
  y = 5;
  return;
}
