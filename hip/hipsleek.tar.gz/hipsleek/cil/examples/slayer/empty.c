/*  Copyright (c) Microsoft Corporation.  All rights reserved. */
void main() {{{{};}; return;}}
