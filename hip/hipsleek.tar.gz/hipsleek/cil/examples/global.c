#include <stdio.h>
//run: obj/x86_LINUX/cilly.byte.exe --noPrintLn examples/input.c --out examples/output.c

int x;
float y;

int main() {
  return 0;
}
