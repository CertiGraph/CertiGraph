#!/bin/sh
./hip -print -tp z3 hoahipex1.ss >hh1.ssr
./hip -print -tp z3 hoahipex2.ss >hh2.ssr
./hip -print -tp z3 hoahipex3.ss >hh3.ssr
./hip -print -tp z3 hoahipex4.ss >hh4.ssr
./hip -print -tp z3 hoahipex5.ss >hh5.ssr
